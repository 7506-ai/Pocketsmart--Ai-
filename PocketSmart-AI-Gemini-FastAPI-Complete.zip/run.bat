@echo off
python -m pip install -r requirements-dev.txt
if not exist .env copy .env.example .env
python -m uvicorn app.main:app --reload
