const catalogue = {
  home: {
    title: 'Home Interior',
    summary: 'A practical home interior plan that keeps a safety reserve.',
    items: [
      ['🛋️', 'Sofa or seating', 'Comfortable everyday seating', 34],
      ['🪵', 'Coffee table', 'A practical centre-piece', 14],
      ['💡', 'Lighting', 'Warm and efficient lighting', 13],
      ['🖼️', 'Wall décor', 'Adds personality to the room', 11],
      ['🪴', 'Indoor plants', 'A fresh low-cost finishing touch', 8],
      ['🧺', 'Storage basics', 'Keeps the space organised', 10]
    ]
  },
  party: {
    title: 'Party Planner',
    summary: 'A balanced event plan covering the most important guest needs.',
    items: [
      ['🏛️', 'Venue setup', 'Space and basic arrangements', 22],
      ['🍽️', 'Food & refreshments', 'The main guest experience', 30],
      ['🎈', 'Decoration', 'Theme-focused visual setup', 14],
      ['📸', 'Photography', 'Captures important moments', 12],
      ['🔊', 'Music & sound', 'Simple event entertainment', 8],
      ['🎁', 'Return gifts', 'A small thank-you for guests', 4]
    ]
  },
  jewellery: {
    title: 'Jewellery',
    summary: 'A careful jewellery purchase plan with quality checks included.',
    items: [
      ['💎', 'Main jewellery piece', 'The priority item for your style', 46],
      ['✨', 'Matching accessory', 'Completes the selected set', 20],
      ['🪙', 'Everyday piece', 'Useful for regular wear', 14],
      ['📦', 'Storage box', 'Protects and organises the items', 5],
      ['🧾', 'Quality check', 'Covers hallmark and purchase checks', 5]
    ]
  }
};

const spendRatios = { Essential: 0.84, Balanced: 0.90, Premium: 0.94 };
const money = value => new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
}).format(value);
const escapeHTML = value => String(value).replace(/[&<>'"]/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
})[character]);

const form = document.querySelector('#planner-form');
const budgetInput = document.querySelector('#budget');
const rangeInput = document.querySelector('#budget-range');
const itemsEl = document.querySelector('#recommendation-items');
const saveButton = document.querySelector('#save-plan');
const generateButton = document.querySelector('#generate-button');
const toast = document.querySelector('#toast');
const apiStatus = document.querySelector('#api-status');
const aiMode = document.querySelector('#ai-mode');
let currentPlan = null;

function getSettings() {
  const category = document.querySelector('input[name="category"]:checked').value;
  const preference = document.querySelector('input[name="preference"]:checked').value;
  const budget = Math.max(5000, Math.min(200000, Number(budgetInput.value) || 25000));
  return {
    category,
    preference,
    budget,
    notes: document.querySelector('#notes').value.trim()
  };
}

function buildLocalPlan(settings = getSettings()) {
  const data = catalogue[settings.category];
  const target = Math.round((settings.budget * spendRatios[settings.preference]) / 100) * 100;
  const totalWeight = data.items.reduce((sum, item) => sum + item[3], 0);
  let allocated = 0;
  const items = data.items.map((item, index) => {
    const amount = index === data.items.length - 1
      ? target - allocated
      : Math.round((target * (item[3] / totalWeight)) / 100) * 100;
    allocated += amount;
    return { icon: item[0], name: item[1], reason: item[2], amount };
  });

  return {
    plan_id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    category: settings.category,
    title: data.title,
    preference: settings.preference,
    budget: settings.budget,
    notes: settings.notes,
    summary: data.summary,
    items,
    total: target,
    remaining: settings.budget - target,
    currency: 'INR',
    source: 'smart_fallback',
    model: null,
    generated_at: new Date().toISOString()
  };
}

function renderPlan(plan) {
  currentPlan = plan;
  budgetInput.value = plan.budget;
  rangeInput.value = plan.budget;
  const usedPercent = Math.round((plan.total / plan.budget) * 100);

  document.querySelector('#budget-display').textContent = money(plan.budget);
  document.querySelector('#saving-display').textContent = money(plan.remaining);
  document.querySelector('#budget-progress').style.width = `${usedPercent}%`;
  document.querySelector('#progress-label').textContent = `${usedPercent}% used`;
  document.querySelector('#result-caption').textContent = `${plan.preference} ${plan.title} plan`;
  document.querySelector('#result-summary').textContent = plan.summary;
  document.querySelector('#remaining-top').textContent = money(plan.remaining);
  document.querySelector('#estimated-total').textContent = money(plan.total);
  document.querySelector('#remaining-total').textContent = money(plan.remaining);

  const sourceBadge = document.querySelector('#source-badge');
  const isGemini = plan.source === 'gemini';
  sourceBadge.textContent = isGemini ? 'Gemini AI' : 'Smart fallback';
  sourceBadge.classList.toggle('fallback', !isGemini);

  itemsEl.innerHTML = plan.items.map(item => `
    <div class="item">
      <div class="item-icon" aria-hidden="true">${escapeHTML(item.icon)}</div>
      <div><strong>${escapeHTML(item.name)}</strong><small>${escapeHTML(item.reason)}</small></div>
      <div class="item-price">${money(item.amount)}</div>
    </div>
  `).join('');

  saveButton.classList.remove('saved');
  saveButton.textContent = '▣ Save this plan';
}

function setLoading(loading) {
  generateButton.disabled = loading;
  generateButton.querySelector('.button-label').textContent = loading ? 'Generating…' : 'Generate Smart Plan';
}

async function generatePlan(settings = getSettings(), { silent = false } = {}) {
  setLoading(true);
  try {
    const response = await fetch('/api/recommendations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    if (!response.ok) throw new Error(`API returned ${response.status}`);
    const plan = await response.json();
    renderPlan(plan);

    const isGemini = plan.source === 'gemini';
    aiMode.classList.toggle('fallback', !isGemini);
    aiMode.querySelector('b').textContent = isGemini ? 'Gemini AI response' : 'Smart fallback active';
    if (!silent) showToast(isGemini ? 'Gemini AI plan generated' : 'Safe fallback plan generated');
    return plan;
  } catch (error) {
    const plan = buildLocalPlan(settings);
    renderPlan(plan);
    apiStatus.classList.add('offline');
    apiStatus.querySelector('b').textContent = 'API unavailable';
    aiMode.classList.add('fallback');
    aiMode.querySelector('b').textContent = 'Offline fallback active';
    if (!silent) showToast('Backend unavailable — local safe plan shown');
    return plan;
  } finally {
    setLoading(false);
  }
}

async function checkHealth() {
  try {
    const response = await fetch('/api/health');
    if (!response.ok) throw new Error('Health check failed');
    const health = await response.json();
    apiStatus.classList.remove('offline');
    apiStatus.querySelector('b').textContent = 'API connected';
    aiMode.classList.toggle('fallback', !health.gemini_configured);
    aiMode.querySelector('b').textContent = health.gemini_configured
      ? 'Gemini AI ready'
      : 'Fallback ready · add API key';
  } catch (error) {
    apiStatus.classList.add('offline');
    apiStatus.querySelector('b').textContent = 'API unavailable';
    aiMode.classList.add('fallback');
    aiMode.querySelector('b').textContent = 'Offline fallback ready';
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('show'), 2200);
}

function readPlans() {
  try {
    const plans = JSON.parse(localStorage.getItem('pocketsmart-plans') || '[]');
    return Array.isArray(plans) ? plans : [];
  } catch (error) {
    return [];
  }
}

function saveCurrentPlan() {
  if (!currentPlan) renderPlan(buildLocalPlan());
  const plans = readPlans();
  plans.unshift({ ...currentPlan, saved_at: new Date().toISOString() });
  localStorage.setItem('pocketsmart-plans', JSON.stringify(plans.slice(0, 20)));
  saveButton.classList.add('saved');
  saveButton.textContent = '✓ Plan saved';
  showToast('Plan saved to History');
  renderHistory();
}

function renderHistory(query = '') {
  const list = document.querySelector('#history-list');
  const normalizedQuery = query.toLowerCase();
  const plans = readPlans().filter(plan =>
    `${plan.title} ${plan.preference}`.toLowerCase().includes(normalizedQuery)
  );

  if (!plans.length) {
    list.innerHTML = `<div class="empty">${query ? 'No saved plan matches your search.' : 'No plans saved yet. Generate a plan and save it here.'}</div>`;
    return;
  }

  list.innerHTML = plans.map(plan => {
    const date = new Date(plan.saved_at || plan.generated_at || Date.now());
    return `
      <article class="history-item">
        <div class="history-item-top">
          <div><h3>${escapeHTML(plan.title)}</h3><span class="step">${escapeHTML(plan.preference)}</span></div>
          <div class="history-price">${money(plan.total)}</div>
        </div>
        <p>${date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })} · ${money(plan.remaining)} reserved</p>
      </article>
    `;
  }).join('');
}

function switchView(view) {
  const planner = document.querySelector('#planner-view');
  const history = document.querySelector('#history-view');
  planner.classList.toggle('hidden', view === 'history');
  history.classList.toggle('active', view === 'history');
  document.querySelectorAll('[data-view]').forEach(button =>
    button.classList.toggle('active', button.dataset.view === view)
  );
  if (view === 'history') renderHistory(document.querySelector('#history-search').value);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

form.addEventListener('submit', event => {
  event.preventDefault();
  generatePlan();
});
budgetInput.addEventListener('input', () => { rangeInput.value = budgetInput.value; });
rangeInput.addEventListener('input', () => {
  budgetInput.value = rangeInput.value;
  document.querySelector('#budget-display').textContent = money(Number(rangeInput.value));
});
saveButton.addEventListener('click', saveCurrentPlan);
document.querySelectorAll('[data-view]').forEach(button =>
  button.addEventListener('click', () => switchView(button.dataset.view))
);
document.querySelector('#history-search').addEventListener('input', event => renderHistory(event.target.value));

renderPlan(buildLocalPlan());
renderHistory();
checkHealth();
